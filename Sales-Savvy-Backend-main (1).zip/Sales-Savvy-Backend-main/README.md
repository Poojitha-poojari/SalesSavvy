Before running this application, ensure that the MySQL database is up and running with the required schemas.
A MySQL script(salessavvy.sql) is included in this repository. Run the script using MySQL Workbench (or any preferred MySQL client) to set up the database correctly. Once the script has been executed successfully, you can run the application to ensure smooth communication with the database. 

