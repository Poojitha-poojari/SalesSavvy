package com.example.demo.entity;

public enum OrderStatus {
	 PENDING,
	    SUCCESS,
	    FAILED
}
