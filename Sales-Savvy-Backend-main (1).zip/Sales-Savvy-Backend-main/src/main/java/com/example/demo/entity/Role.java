package com.example.demo.entity;

public enum Role {
    ADMIN, // Represents the administrator role.
    CUSTOMER // Represents the customer role.
}